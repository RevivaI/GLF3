<!DOCTYPE html>
<html>
<head>
	<title>Trabajo 3 GLF 2020s2</title>
</head>
<body>
	<?php
	include "Funciones.php";
	console_log("A continuación se despliegan dos botones para acceder a EntradaAFP.php o Entrada AP.php para realizar el ingreso");

	?>

<center>
	<h1>¿Que desea ingresar?</h1><br><table border="15"> <th ><form method="post" action="EntradaAFD.php">
	<input type="submit" name="submit1" value="AFD"></form></th><th><form method="post" action="EntradaAP.php">
	<input type="submit" name="submit2" value =" 2 AP"></form></th></table>'
	
</center>
</body>
</html>